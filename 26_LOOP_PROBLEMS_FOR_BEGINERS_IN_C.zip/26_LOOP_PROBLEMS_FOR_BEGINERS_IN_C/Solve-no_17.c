//solve no.17
#include<stdio.h>


int main (){

int n,count=0;
scanf("%d",&n);

while(n){

n/=10;
count++;

}
printf("%d",count);






  return 0;
}