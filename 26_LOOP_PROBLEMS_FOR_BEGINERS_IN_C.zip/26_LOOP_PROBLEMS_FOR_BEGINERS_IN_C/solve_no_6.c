//solve no.6
#include<stdio.h>

int main (){
int n,sum=0;
scanf("%d",&n);
for(int i=1; i<=2*n-1; i+=2){
sum+=i;


}

printf("%d",sum);



}